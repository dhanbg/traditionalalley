                        <button 
                          className="remove-compare-item" 
                          onClick={() => handleRemoveItem(item)}
                          aria-label="Remove item"
                          style={{ top: "-14px", right: "-14px" }}
                        >
                          <i className="icon icon-close"></i>
                        </button> 