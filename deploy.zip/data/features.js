export const iconboxItems = [
  {
    id: 1,
    icon: "icon-sealCheck",
    title: "Quality Product",
    description: "Extra protection for your purchases.",
  },
  {
    id: 2,
    icon: "icon-shipping",
    title: "Global Delivery",
    description: "Worldwide shipping to your doorstep.",
  },
  {
    id: 3,
    icon: "icon-headset",
    title: "24/7 Support",
    description: "24/7 support, always here just for you.",
  },
  {
    id: 4,
    icon: "custom-discount-icon",
    title: "10% Discount",
    description: "Special discount for your first order.",
  },
];
