export const categories = [
    {
      id: 1,
      imgSrc: "/p1.jpg",
      alt: "banner-cls",
      delay: "0s",
      title: "Women",
      imgWidth: 626,
      imgHeight: 833,
    },
    {
      id: 2,
      imgSrc: "/p2.jpg",
      alt: "banner-cls",
      delay: "0.1s",
      title: "Men",
      imgWidth: 626,
      imgHeight: 833,
    },
    {
      id: 3,
      imgSrc: "/p4.jpg",
      alt: "banner-cls",
      delay: "0.2s",
      title: "Kids",
      imgWidth: 626,
      imgHeight: 833,
    },
  ];