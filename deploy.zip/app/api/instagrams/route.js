import { NextResponse } from 'next/server';

const STRAPI_URL = process.env.NEXT_PUBLIC_API_URL || process.env.STRAPI_URL;
const STRAPI_TOKEN = process.env.NEXT_PUBLIC_STRAPI_API_TOKEN || process.env.STRAPI_API_TOKEN;

export async function GET(request) {
  try {
    // Debug environment variables
    console.log('🔧 Instagram API Environment check:');
    console.log('  - STRAPI_URL:', STRAPI_URL);
    console.log('  - STRAPI_TOKEN exists:', !!STRAPI_TOKEN);
    console.log('  - NODE_ENV:', process.env.NODE_ENV);

    if (!STRAPI_URL) {
      console.error('❌ STRAPI_URL is not set');
      return NextResponse.json({ error: 'Server configuration error: STRAPI_URL missing' }, { status: 500 });
    }

    if (!STRAPI_TOKEN) {
      console.error('❌ STRAPI_TOKEN is not set');
      return NextResponse.json({ error: 'Server configuration error: STRAPI_TOKEN missing' }, { status: 500 });
    }

    const apiUrl = `${STRAPI_URL}/api/instagrams?populate=*`;
    console.log('🔗 Fetching Instagram posts from:', apiUrl);

    // Fetch Instagram posts from Strapi
    const response = await fetch(apiUrl, {
      headers: {
        'Authorization': `Bearer ${STRAPI_TOKEN}`,
        'Content-Type': 'application/json',
      },
    });

    console.log('📡 Strapi response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Strapi API error:', response.status, errorText);
      return NextResponse.json({ 
        error: 'Failed to fetch Instagram posts from Strapi',
        details: errorText,
        status: response.status
      }, { status: response.status });
    }

    const data = await response.json();
    console.log('✅ Successfully fetched', data.data?.length || 0, 'Instagram posts');



    // Process the data to ensure proper image URLs and iOS-compatible video codecs
    if (data.data) {
      data.data = data.data.map(post => {
        if (post.media?.url && !post.media.url.startsWith('http')) {
          post.media.url = `${STRAPI_URL}${post.media.url}`;
        }
        

        
        // Handle thumbnail formats
        if (post.media?.formats?.thumbnail?.url && !post.media.formats.thumbnail.url.startsWith('http')) {
          post.media.formats.thumbnail.url = `${STRAPI_URL}${post.media.formats.thumbnail.url}`;
        }
        
        // Handle small formats
        if (post.media?.formats?.small?.url && !post.media.formats.small.url.startsWith('http')) {
          post.media.formats.small.url = `${STRAPI_URL}${post.media.formats.small.url}`;
        }
        
        // Handle medium formats
        if (post.media?.formats?.medium?.url && !post.media.formats.medium.url.startsWith('http')) {
          post.media.formats.medium.url = `${STRAPI_URL}${post.media.formats.medium.url}`;
        }
        
        return post;
      });
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error('❌ Instagram API error:', error);
    return NextResponse.json({ 
      error: 'Internal server error',
      message: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    }, { status: 500 });
  }
}