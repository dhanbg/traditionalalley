import CommingSoon from "@/components/otherPages/CommingSoon";
import React from "react";

export const metadata = {
  title:
    "Comming Soon || Traditional Alley",
  description: "Traditional Alley",
};

export default function page() {
  return (
    <>
      <CommingSoon />
    </>
  );
}
