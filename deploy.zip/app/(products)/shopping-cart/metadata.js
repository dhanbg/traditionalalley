export const metadata = {
  title: "Shopping Cart || Traditional Alley",
  description: "Traditional Alley",
}; 