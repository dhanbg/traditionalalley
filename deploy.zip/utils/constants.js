// Global constants for the application
export const DEFAULT_PLACEHOLDER_IMAGE = '/logo.png';
export const FALLBACK_IMAGE = '/logo.png';
